﻿/*
 * Copyright (c) 2026 ETH Zürich, IT Services
 * 
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/.
 */

namespace SafeExamBrowser.Core.Contracts.Notifications.Events
{
	/// <summary>
	/// Indicates that a notification has changed.
	/// </summary>
	public delegate void NotificationChangedEventHandler();
}
