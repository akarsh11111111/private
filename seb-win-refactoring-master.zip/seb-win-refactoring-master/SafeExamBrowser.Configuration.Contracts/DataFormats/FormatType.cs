﻿/*
 * Copyright (c) 2026 ETH Zürich, IT Services
 * 
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/.
 */

namespace SafeExamBrowser.Configuration.Contracts.DataFormats
{
	/// <summary>
	/// Defines all supported data formats.
	/// </summary>
	public enum FormatType
	{
		Binary = 1,
		Xml
	}
}
